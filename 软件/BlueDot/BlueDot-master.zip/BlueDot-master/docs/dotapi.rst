Blue Dot API
============

.. module:: bluedot

BlueDot
-------

.. autoclass:: BlueDot

BlueDotPosition
---------------

.. autoclass:: BlueDotPosition

BlueDotInteraction
------------------

.. autoclass:: BlueDotInteraction

BlueDotSwipe
------------

.. autoclass:: BlueDotSwipe

BlueDotRotation
---------------

.. autoclass:: BlueDotRotation

MockBlueDot
-----------

.. autoclass:: MockBlueDot
