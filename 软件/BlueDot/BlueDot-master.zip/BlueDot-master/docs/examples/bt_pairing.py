from bluedot import BlueDot
from signal import pause

bd = BlueDot()
bd.allow_pairing()

pause()
