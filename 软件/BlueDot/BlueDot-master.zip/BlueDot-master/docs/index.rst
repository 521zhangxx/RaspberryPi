.. include:: ../README.rst

Table of Contents
=================

.. toctree::
   :maxdepth: 2

   gettingstarted
   pairpiandroid
   pairpipi
   recipes
   bluedotandroidapp
   bluedotpythonapp
   dotapi
   btcommapi
   protocol
   build
   changelog
