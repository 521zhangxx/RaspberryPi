from bluedot import BlueDot

dot = BlueDot()
dot.wait_for_press()
print("You pressed the blue dot - Hello world")
